The AEM.xcodeproj is for generating the AEM.plugin template.
