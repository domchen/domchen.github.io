#include "AEM.h"

typedef struct {
	unsigned long	index;
	char			str[256];
} TableString;

TableString		g_strs[StrID_NUMTYPES] = {
	StrID_NONE,							"",
	StrID_Name,							"AEM",
	StrID_Description,					"AME file plug-in.Copyright 2007-present Dom Chen.",
	StrID_IdleCount,					"AEM : IdleHook called %d times.",	
	StrID_SuiteError,					"Error acquiring suite."
	
};


char	*GetStringPtr(int strNum)
{
	return g_strs[strNum].str;
}
	
