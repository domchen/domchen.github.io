#include "A.h"
#include "AE_GeneralPlug.h"
#include "AEGP_SuiteHandler.h"
#include "AE_Macros.h"

A_Err GetNewFirstLayerInFirstComp(
								  SPBasicSuite		*sP,
								  AEGP_LayerH			*first_layerPH);

