
#ifdef __cplusplus
}		// end extern "C"
#endif



#include <adobesdk/config/PostConfig.h>



#ifndef _AE_GENERAL_PLUG_PRE___
	#error "AE_GeneralPlugPost.h not balanced"
#else
	#undef _AE_GENERAL_PLUG_PRE___
#endif