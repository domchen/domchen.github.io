# aem-plugin
An After Effect plugin for exporting animations to AEM files
